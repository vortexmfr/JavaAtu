package Empresa.Entidades;

public enum Cargos {
    TRABAJADOR, GERENTE , cargo, JEFE
}
